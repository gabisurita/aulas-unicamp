package br.unicamp.ic.mc302.reservaDeQuartos;

import br.unicamp.ic.mc302.dataHora.DataHora;

public class Ocupacao {

	private Quarto quarto;
	private Reserva reserva;
	private DataHora inicio;
	
	public Ocupacao(Quarto q, Reserva r, DataHora entrada) {
		
		this.quarto = q;
		this.reserva = r;
		this.inicio = entrada;
	
	}	
	
	public Quarto quarto(){
		return quarto;
	}
	
	public Reserva reserva(){
		return reserva;
	}
	
	public DataHora inicio(){
		return inicio;
	}

}
