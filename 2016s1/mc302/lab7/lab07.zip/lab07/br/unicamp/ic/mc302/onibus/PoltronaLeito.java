package br.unicamp.ic.mc302.onibus;

public class PoltronaLeito extends Poltrona {

	public PoltronaLeito() {
		super();
	}

	public double preco(){
		return 20.0;
	}

}
