package br.unicamp.ic.mc302.onibus;

public class PoltronaConvencional extends Poltrona {

	public PoltronaConvencional() {
		super();
	}

	public double preco(){
		return 10.0;
	}
}
