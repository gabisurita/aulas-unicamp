package br.unicamp.ic.mc302.onibus;

public class PoltronaEspecial extends Poltrona {

	public PoltronaEspecial() {
		super();
	}

	public double preco(){
		return 25.0;
	}

}
