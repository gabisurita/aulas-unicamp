package br.unicamp.ic.mc302.espaco;

public class Estrela extends CorpoCeleste {

	double temperatura;
	String materialDeFusao;
	
	public Estrela(String nome, double massa, double diametro) {
		super(nome, massa, diametro);
		// TODO Auto-generated constructor stub
	}

	
}
