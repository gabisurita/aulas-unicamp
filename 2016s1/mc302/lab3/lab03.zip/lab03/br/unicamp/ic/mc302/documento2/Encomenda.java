package br.unicamp.ic.mc302.documento2;

public class Encomenda extends Carta2 {

	private String tipo;
	
	public Encomenda(String tipo) {
		
		super();
		this.tipo = tipo;
	}
}
