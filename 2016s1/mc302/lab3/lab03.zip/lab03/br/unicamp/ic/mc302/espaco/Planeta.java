package br.unicamp.ic.mc302.espaco;

public class Planeta extends CorpoCeleste {
	
	protected CorpoCeleste luas[];
	
	public Planeta(String nome, double massa, double diametro) {
		super(nome, massa, diametro);
	}
	

}
