package br.unicamp.ic.mc302.espaco;

public class PlanetaGasoso extends Planeta {

	protected boolean aneis;
	
	public PlanetaGasoso(String nome, double massa, double diametro) {
		super(nome, massa, diametro);
	}

}
