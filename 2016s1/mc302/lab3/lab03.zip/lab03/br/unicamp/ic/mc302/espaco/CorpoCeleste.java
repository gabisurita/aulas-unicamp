package br.unicamp.ic.mc302.espaco;

public class CorpoCeleste {
	
	protected String nome;
	protected double massa;
	protected double diametro;

	public CorpoCeleste(String nome, double massa, double diametro){
		this.nome = nome;
		this.massa = massa;
		this.diametro = diametro;
	}
}
