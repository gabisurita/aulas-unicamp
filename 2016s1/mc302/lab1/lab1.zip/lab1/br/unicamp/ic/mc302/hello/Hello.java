package br.unicamp.ic.mc302.hello;

// arquivo Hello.java
class Hello { 
    static public void main (String args[ ]) { 
        System.out.println("Hello World"); 
    } 
} // fim da classe Hello
