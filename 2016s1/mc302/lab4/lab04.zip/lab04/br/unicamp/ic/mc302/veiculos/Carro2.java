package br.unicamp.ic.mc302.veiculos;

public class Carro2 extends VeiculoMotorizado {
    

	public Carro2(int lot, int num, int ano, String mar, String mod, String pl, int numEixos, int capacidade){	
		super(lot, num, ano, mar, mod, pl);
	}
    
}