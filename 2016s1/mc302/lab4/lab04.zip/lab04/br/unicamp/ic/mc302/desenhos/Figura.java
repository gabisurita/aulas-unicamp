package br.unicamp.ic.mc302.desenhos;

public class Figura {
	
	Tela tela;
	
	public Figura(Tela tela){
		this.tela = tela;
	}
	
	public void desenhar(){
	}

}
