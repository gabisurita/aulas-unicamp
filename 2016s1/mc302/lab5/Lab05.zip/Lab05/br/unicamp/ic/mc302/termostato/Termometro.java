package br.unicamp.ic.mc302.termostato;

public class Termometro {

	private float temperatura = 20;
	public void setTemperatura(float temperatura) {
		this.temperatura = temperatura;
	}
	public float getTemperatura(){
		return temperatura;
	}
	
}
