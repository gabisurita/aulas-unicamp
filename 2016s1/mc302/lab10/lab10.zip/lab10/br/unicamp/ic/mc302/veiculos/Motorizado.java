package br.unicamp.ic.mc302.veiculos;

public interface Motorizado {

	public void ligar();
}
