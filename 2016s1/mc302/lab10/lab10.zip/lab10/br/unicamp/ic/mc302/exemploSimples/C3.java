package br.unicamp.ic.mc302.exemploSimples;

public class C3 implements I3 {

	public void m1() {
		System.out.println("Metodo m1() executado!");
	}
	
	public void m3() {
		System.out.println("Metodo m3() executado!");
	}
}