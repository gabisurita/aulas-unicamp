package br.unicamp.ic.mc302.exemploSimples;

public interface I2 {

	public void m2();
}
