package br.unicamp.ic.mc302.usoInterfaces;

public interface I5 {

	public void m5();

}
