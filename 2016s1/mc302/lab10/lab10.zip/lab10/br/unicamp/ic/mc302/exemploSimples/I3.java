package br.unicamp.ic.mc302.exemploSimples;

public interface I3 extends I1, I2 {

	public void m3();

}