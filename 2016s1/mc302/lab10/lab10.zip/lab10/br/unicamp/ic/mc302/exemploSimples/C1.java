package br.unicamp.ic.mc302.exemploSimples;

public class C1 implements I1, I2 {

	public void m1() {
		System.out.println("Metodo m1() executado!");
	}

	public void m2() {
		System.out.println("Metodo m2() executado!");		
	}
}

