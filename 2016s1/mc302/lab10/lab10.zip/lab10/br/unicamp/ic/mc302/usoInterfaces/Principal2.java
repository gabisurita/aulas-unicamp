package br.unicamp.ic.mc302.usoInterfaces;

public class Principal2 {

	public static void main(String args[]) {

		C4 obj = new C4();
		obj.m4();
		obj.m5();
	}
}
