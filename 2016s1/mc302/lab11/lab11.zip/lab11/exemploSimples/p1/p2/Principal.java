package p1.p2;

import p1.C2;

public class Principal {

    public static void main(String args[]) {
    
        C1 obj = new C1();
        obj.m1();    
        C2 obj2 = new C2();
        obj2.m2();    
    }
}
