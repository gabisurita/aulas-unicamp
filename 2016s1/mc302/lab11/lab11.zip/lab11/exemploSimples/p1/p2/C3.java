package p1.p2;

public class C3 {

    public void m3()
    {
        System.out.println("Metodo m3() da classe C3 executado!");
    }
}
