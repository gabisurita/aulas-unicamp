package br.unicamp.ic.mc302.veiculos;

public abstract class EstadoVeiculo {

	public abstract void andar();
}
