package br.unicamp.ic.mc302.motor;

public class PrincipalFacade {

	public static void main(String[] args) {
		
		Motor mot = new Motor();
		mot.ligar();
	}
}
