package br.unicamp.ic.mc302.veiculos;

public class VeiculoMaritimo extends EstadoVeiculo {

	public void andar(){
		System.out.println("--- andar na agua ---");
	}

}
