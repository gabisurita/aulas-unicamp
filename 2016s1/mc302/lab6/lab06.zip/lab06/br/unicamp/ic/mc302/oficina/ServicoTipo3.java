package br.unicamp.ic.mc302.oficina;

public class ServicoTipo3 extends Servico {

	public ServicoTipo3(String cliente, String nome) {
		super(cliente, "Tipo3", 40);
	}

	public ServicoTipo3() {
		super("", "Tipo3", 40);
	}
}
