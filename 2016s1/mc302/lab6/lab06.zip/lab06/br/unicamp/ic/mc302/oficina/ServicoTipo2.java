package br.unicamp.ic.mc302.oficina;

public class ServicoTipo2 extends Servico {

	public ServicoTipo2(String cliente, String nome) {
		super(cliente, "Tipo2", 50);
	}

	public ServicoTipo2() {
		super("", "Tipo2", 50);
	}

}
